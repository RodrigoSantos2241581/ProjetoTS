﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    public class Mensagem
    {
        public int Id { get; set; }
        [Required]
        public string Conteudo { get; set; }
        [Required]
        public string Remetente { get; set; }
        [Required]
        public string Destinatario { get; set; }

    }
}
