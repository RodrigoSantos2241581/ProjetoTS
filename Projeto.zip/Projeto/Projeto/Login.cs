﻿using EI.SI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Projeto
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        public void btEntrar_Click(object sender, EventArgs e)
        {

            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=UtilizadoresDB;Integrated Security=True";
            string username = textBox1.Text;
            string password = textBox2.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM Utilizadors WHERE Nome = @Nome AND Password = @Password";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Nome", username);
                        cmd.Parameters.AddWithValue("@Password", password);

                        int count = (int)cmd.ExecuteScalar();

                        if (count > 0)
                        {
                            MessageBox.Show("Login bem-sucedido!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Manter a conexão aberta passando o client para o Form1
                            TcpClient client = new TcpClient("127.0.0.1", 10000);
                            NetworkStream stream = client.GetStream();
                            ProtocolSI protocol = new ProtocolSI();


                            string mensagem = $"Utilizador: {username} conectou-se ao servidor.";
                            byte[] data = protocol.Make(ProtocolSICmdType.DATA, mensagem);
                            stream.Write(data, 0, data.Length);

                            // Passar o client e stream para o Form1
                            Form1 form1 = new Form1(username, client, stream);
                            form1.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Nome de utilizador ou palavra-passe incorretos.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
        }

        private void btCriar_Click(object sender, EventArgs e)
        {
            this.Hide();
            CriarConta criarConta = new CriarConta();
            criarConta.ShowDialog();
        }
    }
}
