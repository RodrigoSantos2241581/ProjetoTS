﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class CriarConta: Form
    {
        public Utilizador Utilizador { get; private set; }
        public CriarConta()
        {
            InitializeComponent();
        }

        private void buttonCriar_Click(object sender, EventArgs e)
        {
            string Nome = textBox1.Text;
            string Password = textBox2.Text;
            
            if (string.IsNullOrEmpty(Nome) || string.IsNullOrEmpty(Password) )
            {
                MessageBox.Show("Por favor, preencha todos os campos obrigatórios.", "Aviso",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var db = new UtilizadoresDB())
            {
                if(!db.Utilizadores.Any(u => u.Nome == Nome))
                {
                    var utilizador = new Utilizador
                    {
                        Nome = Nome,
                        Password = Password
                    };

                    db.Utilizadores.Add(utilizador);
                    db.SaveChanges();
                    Utilizador = utilizador;
                }
                else
                {
                    MessageBox.Show("Já existe um utilizador com este nome.", "Erro",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            this.DialogResult = DialogResult.OK;
            this.Hide();

            Login login = new Login();
            login.ShowDialog();
            
        }
    }
}
