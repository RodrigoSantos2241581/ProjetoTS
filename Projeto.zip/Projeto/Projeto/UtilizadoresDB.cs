﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Data.Entity.Migrations.Model.UpdateDatabaseOperation;

namespace Projeto
{
    public class UtilizadoresDB : DbContext
    {
        public UtilizadoresDB() : base("UtilizadoresDB")
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<UtilizadoresDB, Projeto.Migrations.Configuration>());
        }

        public DbSet<Utilizador> Utilizadores { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
