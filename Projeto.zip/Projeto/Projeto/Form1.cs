﻿using EI.SI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class Form1 : Form
    {
        private const int PORT = 10000;
        private NetworkStream networkStream;
        private ProtocolSI protocolSI;
        private TcpClient client;
        private List<Utilizador> utilizadores;
        private string utilizadorAtual;
        private bool isClosing = false;

        public Form1(string utilizador, TcpClient existingClient, NetworkStream existingStream)
        {
            InitializeComponent();

            this.utilizadorAtual = utilizador;
            this.client = existingClient;
            this.networkStream = existingStream;
            this.protocolSI = new ProtocolSI();
            this.utilizadores = new List<Utilizador>();

            label3.Text = utilizadorAtual;

            client.ReceiveTimeout = 5000;
            client.SendTimeout = 5000;

            Task.Run(() => ReceiveMessages());

            CarregarContactos();
        }

        public void CarregarContactos()
        {
            try
            {
                utilizadores.Add(new Utilizador { Nome = "Utilizador1" });
                utilizadores.Add(new Utilizador { Nome = "Utilizador2" });
                utilizadores.Add(new Utilizador { Nome = "Utilizador3" });
                listBoxContactos.DataSource = utilizadores.Select(u => u.Nome).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar contactos: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private async Task ReceiveMessages()
        {
            try
            {
                while (client != null && client.Connected && !isClosing)
                {
                    try
                    {
                        int bytesRead = await networkStream.ReadAsync(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
                        if (bytesRead == 0) break;

                        switch (protocolSI.GetCmdType())
                        {
                            case ProtocolSICmdType.DATA:
                                string message = protocolSI.GetStringFromData();
                                UpdateChatBox(message);
                                break;
                            case ProtocolSICmdType.ACK:
                                // Processar ACK se necessário
                                break;
                        }
                    }
                    catch (IOException) { break; }
                    catch (ObjectDisposedException) { break; }
                }
            }
            catch (Exception ex)
            {
                if (!isClosing)
                {
                    Invoke((MethodInvoker)delegate {
                        MessageBox.Show($"Erro na conexão: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    });
                }
            }
        }

        private void UpdateChatBox(string message)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { UpdateChatBox(message); });
                return;
            }

            // Adiciona a mensagem ao chat (ajuste conforme seus controles)
            // Exemplo: textBoxChat.AppendText(message + Environment.NewLine);
        }


        private void listBoxContactos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxContactos.SelectedItem != null)
            {
                textBoxNome.Text = listBoxContactos.SelectedItem.ToString();
            }
        }

        private async void buttonEnviarMensagem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxMessage.Text)) return;

            try
            {
                string msg = $"{utilizadorAtual}: {textBoxMessage.Text}";
                byte[] packet = protocolSI.Make(ProtocolSICmdType.DATA, msg);

                await networkStream.WriteAsync(packet, 0, packet.Length);
                textBoxMessage.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao enviar mensagem: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            isClosing = true;

            try
            {
                if (networkStream != null)
                {
                    // Enviar comando de fim de transmissão
                    byte[] eotPacket = protocolSI.Make(ProtocolSICmdType.EOT);
                    networkStream.Write(eotPacket, 0, eotPacket.Length);
                    networkStream.Close();
                }
            }
            catch { /* Ignorar erros no fechamento */ }

            try
            {
                if (client != null)
                {
                    client.Close();
                }
            }
            catch { /* Ignorar erros no fechamento */ }

            base.OnFormClosing(e);
        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            var login = new Login();
            this.Hide();
            login.ShowDialog();
            this.Close();
        }
    }
}