﻿using EI.SI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class Form1 : Form
    {
        private const int PORT = 10000;
        private NetworkStream networkStream;
        private ProtocolSI protocolSI;
        private TcpClient client;
        private List<Utilizador> utilizadores;
        private string utilizadorAtual;
        private bool isClosing = false;

        public Form1(string utilizador, TcpClient existingClient, NetworkStream existingStream)
        {
            InitializeComponent();

            this.utilizadorAtual = utilizador;
            this.client = existingClient;
            this.networkStream = existingStream;
            this.protocolSI = new ProtocolSI();
            this.utilizadores = new List<Utilizador>();

            label3.Text = utilizadorAtual;

            client.ReceiveTimeout = 5000;
            client.SendTimeout = 5000;

            Task.Run(() => ReceiveMessages());

            CarregarContactos();

            
        }
        public void CarregarMensagens()
        {
            try
            {
                // Verifica se há um item selecionado
                if (listBoxContactos.SelectedItem == null)
                {
                    MessageBox.Show("Selecione um contacto para ver as mensagens.", "Aviso",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Obtém o NOME do destinatário selecionado (como string)
                string nomeDestinatario = listBoxContactos.SelectedItem.ToString();

                lstMensagens.Items.Clear();

                using (var db = new UtilizadoresDB())
                {
                    // Filtra mensagens entre o utilizador atual e o selecionado
                    var mensagens = db.Mensagens
                        .Where(m => (m.Remetente == utilizadorAtual && m.Destinatario == nomeDestinatario) ||
                                    (m.Remetente == nomeDestinatario && m.Destinatario == utilizadorAtual))
                        .ToList();

                    foreach (var mensagem in mensagens)
                    {
                        string msg = $"{mensagem.Remetente}: {mensagem.Conteudo}";
                        lstMensagens.Items.Add(msg);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar mensagens: {ex.Message}", "Erro",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void CarregarContactos()
        {
            listBoxContactos.Items.Clear();
            using (var db = new UtilizadoresDB())
            {
                var contactos = db.Utilizadores.ToList();
                foreach (var contacto in contactos)
                {
                    if (contacto.Nome != utilizadorAtual) // Evitar adicionar o próprio utilizador
                    {
                        listBoxContactos.Items.Add(contacto.Nome);
                    }
                }
            }
        }


        private async Task ReceiveMessages()
        {
            try
            {
                while (client != null && client.Connected && !isClosing)
                {
                    try
                    {
                        int bytesRead = await networkStream.ReadAsync(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
                        if (bytesRead == 0) break;

                        switch (protocolSI.GetCmdType())
                        {
                            case ProtocolSICmdType.DATA:
                                string message = protocolSI.GetStringFromData();
                                UpdateChatBox(message);
                                break;
                            case ProtocolSICmdType.ACK:
                                // Processar ACK se necessário
                                break;
                        }
                    }
                    catch (IOException) { break; }
                    catch (ObjectDisposedException) { break; }
                }
            }
            catch (Exception ex)
            {
                if (!isClosing)
                {
                    Invoke((MethodInvoker)delegate {
                        MessageBox.Show($"Erro na conexão: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    });
                }
            }
        }

        private void UpdateChatBox(string message)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { UpdateChatBox(message); });
                return;
            }

            // Adiciona a mensagem ao chat (ajuste conforme seus controles)
            // Exemplo: textBoxChat.AppendText(message + Environment.NewLine);
        }


        private void listBoxContactos_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstMensagens.Items.Clear();
            CarregarMensagens();
            if (listBoxContactos.SelectedItem != null)
            {
                textBoxNome.Text = listBoxContactos.SelectedItem.ToString();
            }
        }

        private async void buttonEnviarMensagem_Click(object sender, EventArgs e)
        {
            CarregarMensagens();
            if (string.IsNullOrWhiteSpace(textBoxMessage.Text)) return;

            try
            {
                // 1. Obter o destinatário selecionado no ListBox
                string destinatario = listBoxContactos.SelectedItem?.ToString(); // Nome do contacto selecionado
                if (string.IsNullOrEmpty(destinatario))
                {
                    MessageBox.Show("Selecione um contacto para enviar a mensagem!", "Aviso",
                                   MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 2. Criar a mensagem (formato: "Remetente: Mensagem")
                string msg = $"{utilizadorAtual}: {textBoxMessage.Text} para {listBoxContactos.SelectedItem}";
                byte[] packet = protocolSI.Make(ProtocolSICmdType.DATA, msg);

                // 3. Enviar a mensagem via TCP
                await networkStream.WriteAsync(packet, 0, packet.Length);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao enviar mensagem: {ex.Message}", "Erro",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Guardar a mensagem na base de dados
            try
            {
                using (var db = new UtilizadoresDB())
                {
                    var mensagem = new Mensagem
                    {
                        Remetente = utilizadorAtual,
                        Destinatario = listBoxContactos.SelectedItem.ToString(),
                        Conteudo = textBoxMessage.Text
                    };
                    db.Mensagens.Add(mensagem);
                    await db.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao guardar mensagem: {ex.Message}", "Erro",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            isClosing = true;

            try
            {
                if (networkStream != null)
                {
                    // Enviar comando de fim de transmissão
                    byte[] eotPacket = protocolSI.Make(ProtocolSICmdType.EOT);
                    networkStream.Write(eotPacket, 0, eotPacket.Length);
                    networkStream.Close();
                }
            }
            catch { /* Ignorar erros no fechamento */ }

            try
            {
                if (client != null)
                {
                    client.Close();
                }
            }
            catch { /* Ignorar erros no fechamento */ }

            base.OnFormClosing(e);
        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            var login = new Login();
            this.Hide();
            login.ShowDialog();
            this.Close();
        }
    }
}