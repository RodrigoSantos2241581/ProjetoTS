﻿using EI.SI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Projeto_Server
{
    public class Server
    {
        public const int PORT = 10000;
        static void Main(string[] args)
        {
            IPEndPoint endpoint = new IPEndPoint(IPAddress.Any, PORT);
            TcpListener listener = new TcpListener(endpoint);

            listener.Start();
            Console.WriteLine("Server Ready");
            int clientCounter = 0;

            while (true)
            {
                try
                {
                    TcpClient client = listener.AcceptTcpClient();
                    NetworkStream networkStream = client.GetStream();

                    // Esperar nome do utilizador
                    ProtocolSI protocolSI = new ProtocolSI();
                    networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
                    string nome = protocolSI.GetStringFromData();

                    clientCounter++;
                    Console.WriteLine($"{nome}.");

                    ClientHandler clientHandler = new ClientHandler(client, clientCounter);
                    clientHandler.Handle();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao aceitar cliente: {ex.Message}");
                }
            }
        }


    }

    public class ClientHandler
    {
        public TcpClient client;
        public int clientId;

        public ClientHandler(TcpClient client, int clientId)
        {
            this.client = client;
            this.clientId = clientId;
        }

        public void Handle()
        {
            Thread thread = new Thread(ThreadHandler);
            thread.Start();
        }

        public void ThreadHandler()
        {
            try
            {
                NetworkStream networkStream = this.client.GetStream();
                ProtocolSI protocolSI = new ProtocolSI();

                while (client.Connected && protocolSI.GetCmdType() != ProtocolSICmdType.EOT)
                {
                    try
                    {
                        int bytesRead = networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
                        if (bytesRead == 0) break; // Cliente desconectou

                        byte[] ack;
                        switch (protocolSI.GetCmdType())
                        {
                            case ProtocolSICmdType.DATA:
                                string nome = protocolSI.GetStringFromData();
                                Console.WriteLine($"'{nome}'");
                                ack = protocolSI.Make(ProtocolSICmdType.ACK);
                                networkStream.Write(ack, 0, ack.Length);
                                break;
                            case ProtocolSICmdType.EOT:
                                Console.WriteLine($"Cliente {clientId} terminou a conexão.");
                                ack = protocolSI.Make(ProtocolSICmdType.ACK);
                                networkStream.Write(ack, 0, ack.Length);
                                break;
                        }
                    }
                    catch (IOException ex)
                    {
                        Console.WriteLine($"[Erro] Ligação com o cliente {clientId} foi encerrada: {ex.Message}");
                        break;
                    }
                }
            }
            finally
            { // Uso do bloco finally para garantir que o cliente seja fechado corretamente

                client?.Close();         // Uso correto do null-conditional operator
                Console.WriteLine($"Ligação com cliente {clientId} terminada.");  // Adicionado interpolação
            }
        }
    }
}
